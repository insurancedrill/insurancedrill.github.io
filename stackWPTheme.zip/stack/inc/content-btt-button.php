<a class="back-to-top inner-link" href="#start" data-scroll-class="100vh:active">
	<i class="stack-interface stack-up-open-big"></i>
</a>