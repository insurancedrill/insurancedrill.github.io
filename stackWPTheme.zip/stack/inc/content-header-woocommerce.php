<?php
	global $woocommerce;
	$cart_url = $woocommerce->cart->get_cart_url();
?>

<a class="cart-link" href="<?php echo esc_url($cart_url); ?>">
	<i class="stack-basket"></i>
</a>