<div class="masonry-filter-container">
	<span><?php esc_html_e('Category:', 'stack'); ?></span>
	<div class="masonry-filter-holder">
		<div class="masonry__filters" data-filter-all-text="<?php esc_html_e('All Categories', 'stack'); ?>"></div>
	</div>
</div>