<span><?php esc_html_e('Category:', 'stack'); ?></span>
<div class="masonry-filter-holder masonry-filter-holder-post">
	<div class="masonry__filters blog-filters">
		<ul>
			<li class="active"><?php esc_html_e('All Categories', 'stack'); ?></li>
			<?php wp_list_categories('title_li='); ?>
		</ul>
	</div>
</div>