<section class="vim" id="variant-account-recover" vbr="Account Login 3" vbp="utility">
<section class="height-100 text-center">
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-7 col-md-5">
                <div class="wysiwyg">
                    <h2>Login to continue</h2>
                    <p class="lead">
                        Welcome back, sign in with your existing Stack account credentials
                    </p>
                </div>
                <div class="variant-shortcode" data-shortcode-name="stack_login"></div>
            </div>
        </div>
    </div>
</section>
</section>