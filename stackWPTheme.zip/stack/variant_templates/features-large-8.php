<!--META--><section class="vim" id="variant-features-large-8" vbr="Features Large 8" vbp="features large">
<section class="space--sm switchable switchable--switch  ">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="height-50 imagebg border--round" data-overlay="2">
                    <div class="background-image-holder"><img alt="background" src="<?php variant_page_builder_demo_img('inner-8.jpg'); ?>"></div>
                    <div class="pos-vertical-center col-sm-6 boxed boxed--lg bg--none wysiwyg">
                        <h2>Design-driven and perfect for modern startups</h2>
                        <p class="lead">
                            Stack offers a clean and contemporary to suit a range of purposes from corporate, tech startup, marketing site to digital storefront.
                        </p>
                    </div>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->