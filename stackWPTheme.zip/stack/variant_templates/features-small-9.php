<!--META--><section class="vim" id="variant-features-small-9" vbr="Features Small 9" vbp="features small">
<section class=" ">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-4 voh">
                <div class="feature wysiwyg">
                    <img alt="Image" src="<?php variant_page_builder_demo_img('cowork-6.jpg'); ?>" class="border--round">
                    <h4>Startups</h4>
                    <p>
                        Quickly launch a professional site — minimal effort, maximum impact.
                    </p>
                </div>
            </div>
            <div class="col-sm-4 voh">
                <div class="feature wysiwyg">
                    <img alt="Image" src="<?php variant_page_builder_demo_img('cowork-1.jpg'); ?>" class="border--round">
                    <h4>Agencies</h4>
                    <p>
                        Deliver results to your clients faster than ever with rapid page building.
                    </p>
                </div>
            </div>
            <div class="col-sm-4 voh">
                <div class="feature wysiwyg">
                    <img alt="Image" src="<?php variant_page_builder_demo_img('education-1.jpg'); ?>" class="border--round">
                    <h4>Freelancers</h4>
                    <p>
                        Stack is your silent partner, it does the heavy-lifting while you take the glory!
                    </p>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->