<!--META--><section class="vim" id="variant-instagram-feed-2-bg" vbr="Instagram Feed 2 BG" vbp="social">
<section class="text-center imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="heading-block wysiwyg">
                    <h2>Follow us for updates and more</h2>
                </div>
                <div class="instafeed" data-user-name="tommusrhodus" data-amount="6" data-grid="6"></div>
                <a class="btn btn--icon bg--instagram type--uppercase" href="#">
                    <span class="btn__text">
                        <i class="socicon socicon-instagram"></i>
                        Follow @tommusrhodus
                    </span>
                </a>
            </div>
        </div><!--end row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->