<!--META--><section class="vim" id="variant-cover-video-3" vbr="Cover Video 3" vbp="covers">
<section class="cover height-100 text-center">
	<div class="container pos-vertical-center">
		<div class="row">
			<div class="col-sm-6 col-md-4">
				<div class="wysiwyg">
					<h1 class="color--primary">Hi, I'm Stack</h1>
					<h1>Smart, simple<br class="hidden-xs hidden-sm"> and responsive.</h1>
				</div>
				<a class="btn btn--primary type--uppercase" href="#customise-template">
					<span class="btn__text">
						Launch The Builder
					</span>
				</a>
				<div class="modal-instance block vog">
					<div class="video-play-icon video-play-icon--xs modal-trigger bg--primary vog"></div>
					<span>Watch Overview</span>
					<div class="modal-container vog">
						<div class="modal-content bg-dark vog" data-width="60%" data-height="60%">
							<iframe allowfullscreen="allowfullscreen" no-src="https://www.youtube.com/embed/6p45ooZOOPo?autoplay=1"></iframe>
						</div><!--end of modal-content-->
					</div><!--end of modal-container-->
				</div><!--end of modal instance-->
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->