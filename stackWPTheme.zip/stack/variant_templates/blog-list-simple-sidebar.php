<!--META--><section class="vim" id="variant-blog-list-simple-sidebar" vbr="Blog List Simple & Sidebar" vbp="blog">
<section class="space--sm">
	<div class="container">
		<div class="variant-shortcode" data-shortcode-name="stack_post" data-param-layout="list-sidebar" data-param-pppage="3" data-param-filter="all"></div>
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->