<!--META--><section class="vim" id="variant-blog-carousel" vbr="Blog Carousel" vbp="blog">
<section class="space--sm">
	<div class="container">
		<div class="variant-shortcode" data-shortcode-name="stack_post" data-param-layout="carousel" data-param-pppage="6" data-param-filter="all"></div>
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->