<!--META--><section class="vim" id="variant-blog-magazine-simple" vbr="Blog Magazine Simple" vbp="blog">
<section class="space--sm">
	<div class="container">
		<div class="variant-shortcode" data-shortcode-name="stack_post" data-param-layout="magazine-simple" data-param-pppage="8" data-param-filter="all"></div>
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->