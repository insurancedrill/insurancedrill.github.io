<!--META--><section class="vim" id="variant-cta-centered-2-gradient" vbr="CTA Centered 2 Gradient" vbp="CTA">
<section class="text-center imagebg" data-gradient-bg="#4876BD,#5448BD,#8F48BD,#BD48B1">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-md-6">
                <div class="cta">
                    <div class="wysiwyg"><h2>Make your site stand out</h2></div>
                    <a class="btn btn--primary type--uppercase" href="#purchase-template">
                        <span class="btn__text">
                            Purchase Stack Now
                        </span>
                        <span class="label">$59 USD</span>
                    </a>
                    <div class="wysiwyg"><p class="type--fine-print">or check out <a href="/">more demos</a></p></div>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->