<!--META--><section class="vim" id="variant-cta-button" vbr="CTA Button" vbp="CTA">
<section class="bg--primary unpad cta cta-2 text-center">
	<a href="#purchase-template">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h2>Build a beautiful site with Stack</h2>
				</div>
			</div><!--end of row-->
		</div><!--end of container-->
	</a>
</section>
</section><!--end of meta Section container-->