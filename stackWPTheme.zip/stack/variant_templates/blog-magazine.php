<!--META--><section class="vim" id="variant-blog-magazine" vbr="Blog Magazine" vbp="blog">
<section class="space--sm">
	<div class="container">
		<div class="variant-shortcode" data-shortcode-name="stack_post" data-param-layout="magazine" data-param-pppage="7" data-param-filter="all"></div>
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->