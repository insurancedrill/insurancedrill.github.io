<!--META--><section class="vim" id="variant-gallery-video-1" vbr="Gallery Video 1" vbp="gallery">
<section class=" ">
    
    <div class="container">
        <div class="row">
            <div class="masonry">
                <div class="masonry-filter-container text-center">
                    <span>Category:</span>
                    <div class="masonry-filter-holder">
                        <div class="masonry__filters" data-filter-all-text="All Categories"></div>
                    </div>
                </div><!--end masonry filters-->
                <div class="masonry__container">
                    <div class="masonry__item col-sm-6 col-xs-12 voh vnn" data-masonry-filter="Filter 1">
                        <div class="video-cover border--round">
                            <div class="background-image-holder">
                                <img alt="image" src="<?php variant_page_builder_demo_img('blog-1.jpg'); ?>">
                            </div>
                            <div class="video-play-icon"></div>
                            <iframe allowfullscreen="allowfullscreen" no-src="https://www.youtube.com/embed/6p45ooZOOPo?autoplay=1"></iframe>
                        </div><!--end video cover-->
                        <span class="h4 inline-block">Video Title</span>
                        <span>Detailed Description</span>
                    </div>
                    <div class="masonry__item col-sm-6 col-xs-12 voh vnn" data-masonry-filter="Filter 1">
                        <div class="video-cover border--round">
                            <div class="background-image-holder">
                                <img alt="image" src="<?php variant_page_builder_demo_img('blog-2.jpg'); ?>">
                            </div>
                            <div class="video-play-icon"></div>
                            <iframe allowfullscreen="allowfullscreen" no-src="https://www.youtube.com/embed/6p45ooZOOPo?autoplay=1"></iframe>
                        </div><!--end video cover-->
                        <span class="h4 inline-block">Video Title</span>
                        <span>Detailed Description</span>
                    </div>
                    
                    
                </div><!--end masonry container-->
            </div><!--end masonry-->
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->