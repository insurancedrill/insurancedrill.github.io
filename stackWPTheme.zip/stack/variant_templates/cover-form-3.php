<!--META--><section class="vim" id="variant-cover-form-3" vbr="Cover Form 3" vbp="covers">
<section class="cover imagebg height-100 text-center" data-overlay="4">
	<div class="background-image-holder"><img alt="background" src="<?php variant_page_builder_demo_img('agency-2.jpg'); ?>"></div>
	<div class="container pos-vertical-center">
		<div class="row">
			<div class="col-sm-12">
				<div class="wysiwyg">
					<h1>Streamline your workflow with Stack</h1>
					<p class="lead">
						Clean and contemporary design to suit a range of purposes.
					</p>
				</div>
				<div class="row">
					<div class="cf7-holder">
						<div class="variant-shortcode vru" data-shortcode-name="contact-form-7" data-param-title="" data-param-id="none">
							<p class="lead">Manage this form using the section sidebar <i class="material-icons">&#xE5C8;</i></p>
						</div>
					</div>
                </div><!--end of row-->
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->