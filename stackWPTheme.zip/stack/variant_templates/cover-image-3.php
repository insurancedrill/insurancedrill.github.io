<!--META--><section class="vim" id="variant-cover-image-3" vbr="Cover Image 3" vbp="covers">
<section class="cover bg--secondary text-center unpad--bottom">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="typed-headline">
					<span class="h2 inline-block">I'm Stack — A killer template for</span>
					<span class="h2 inline-block typed-text typed-text--cursor color--primary" data-typed-strings="startups,SaaS,marketing sites, portfolios,blogging,rapid development,business,showcasing products"></span>
				</div>
			</div>
		</div><!--end of row-->
		<div class="row">
			<div class="col-sm-12 col-md-10 col-md-offset-1">
				<img class="unmarg--bottom box-shadow-wide" alt="Image" src="<?php variant_page_builder_demo_img('device-4.png'); ?>">
				<div class="bg--dark box-shadow-wide">
					<img class="unmarg--bottom" alt="Image" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
				</div>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->