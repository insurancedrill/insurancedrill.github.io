<!--META--><section class="vim" id="variant-gallery-projects-4" vbr="Gallery Projects 4" vbp="gallery">
<section class="unpad">
    <div class="masonry masonry--gapless">
        <div class="masonry__container">
            <div class="masonry__item col-md-4 col-sm-6 col-xs-12 voh vnn" data-masonry-filter="Digital">
                <div class="project-thumb hover-element height-50">
                    <a href="#">
                        <div class="hover-element__initial">
                            <div class="background-image-holder">
                                <img alt="background" src="<?php variant_page_builder_demo_img('work-6.jpg'); ?>">
                            </div>
                        </div>
                        <div class="hover-element__reveal" data-overlay="9">
                            <div class="project-thumb__title">
                                <h5>Nike Active</h5>
                                <span>Digital Marketing</span>
                            </div>
                        </div>
                    </a>
                </div>
            </div><!--end item-->
            <div class="masonry__item col-md-8 col-sm-6 col-xs-12 voh vnn" data-masonry-filter="Digital">
                <div class="project-thumb hover-element height-50">
                    <a href="#">
                        <div class="hover-element__initial">
                            <div class="background-image-holder">
                                <img alt="background" src="<?php variant_page_builder_demo_img('work-1.jpg'); ?>">
                            </div>
                        </div>
                        <div class="hover-element__reveal" data-overlay="9">
                            <div class="project-thumb__title">
                                <h5>Unvest Capital</h5>
                                <span>Brand Collateral</span>
                            </div>
                        </div>
                    </a>
                </div>
            </div><!--end item-->
            <!--end item-->
            <!--end item-->
        </div><!--end of masonry container-->
    </div><!--end masonry-->
</section>
</section><!--end of meta Section container-->