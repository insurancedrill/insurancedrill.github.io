<!--META--><section class="vim" id="variant-features-large-2" vbr="Features Large 2" vbp="features large">
<section class="switchable ">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-7">
                <img alt="Image" src="<?php variant_page_builder_demo_img('device-2.png'); ?>">
            </div>
            <div class="col-sm-5 col-md-4">
                <div class="switchable__text wysiwyg">
                    <h3>Experience quality</h3>
                    <p class="lead">
                        Stack is built with customization and ease-of-use at its core — whether you're a seasoned developer or just starting out, you'll be making attractive sites faster than any traditional WordPress Theme.
                    </p>
                    <hr class="short">
                    <p>
                        Each purchase of Stack includes six months of free support and lifetime free content and bug-fix updates.
                    </p>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->