<!--META--><section class="vim" id="variant-features-large-7" vbr="Features Large 7" vbp="features large">
<section class="imagebg feature-large-7 switchable">
	<div class="background-image-holder">
		<img alt="background" src="<?php variant_page_builder_demo_img('recruitment-4.jpg'); ?>">
	</div>
	<div class="container">
		<div class="row">
			<div class="col-sm-7 col-md-5">
				<div class="boxed boxed--lg border--round bg--white">
					<div class="col-md-10 col-md-offset-1 col-sm-12 wysiwyg">
					<h3>Experience quality</h3>
					<p class="lead">
						Stack is built with customization and ease-of-use at its core — whether you're a seasoned developer or just starting out, you'll be making attractive sites faster than any traditional WordPress Theme.
					</p>
					<hr class="short">
					<p>
						Each purchase of Stack includes six months of free support and lifetime free content and bug-fix updates.
					</p>
					</div>
				</div>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->