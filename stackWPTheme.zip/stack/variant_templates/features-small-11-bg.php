<!--META--><section class="vim" id="variant-features-small-11-bg" vbr="Features Small 11 BG" vbp="features small">
<section class="text-center imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
    <div class="container">
        <div class="row">
            <div class="col-sm-3 voh">
                <a href="#" class="block">
                    <div class="feature boxed boxed--border border--round">
                        <i class="icon--lg icon-Credit-Card2"></i>
                        <span class="h5 color--primary">Payments and Billing</span>
                    </div>
                </a>
            </div>
            <div class="col-sm-3 voh">
                <a href="#" class="block">
                    <div class="feature boxed boxed--border border--round">
                        <i class="icon--lg icon-Cloud"></i>
                        <span class="h5 color--primary">Account Management</span>
                    </div>
                </a>
            </div>
            <div class="col-sm-3 voh">
                <a href="#" class="block">
                    <div class="feature boxed boxed--border border--round">
                        <i class="icon--lg icon-Checked-User"></i>
                        <span class="h5 color--primary">Permissions</span>
                    </div>
                </a>
            </div>
            <div class="col-sm-3 voh">
                <a href="#" class="block">
                    <div class="feature boxed boxed--border border--round">
                        <i class="icon--lg icon-Handshake"></i>
                        <span class="h5 color--primary">Integrations</span>
                    </div>
                </a>
            </div> 
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->