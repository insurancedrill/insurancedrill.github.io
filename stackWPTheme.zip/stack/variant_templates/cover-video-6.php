<!--META--><section class="vim" id="variant-cover-video-6" vbr="Cover Video 6" vbp="covers">
<section class="cover height-80">
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-11 col-md-8">
                <div class="wysiwyg"><span class="h2">
                    <span class="color--primary">Hi, we're Stack</span> a digital design firm specialising in end-to-end marketing campaigns. We partner with startups and companies, small and large. 
                </span></div>
                <div class="modal-instance block vog">
                    <div class="video-play-icon video-play-icon--sm bg--primary modal-trigger vog"></div>
                    <span><strong>Watch our film</strong>&nbsp;&nbsp;&nbsp;104 Seconds</span>
                    <div class="modal-container vog">
                        <div class="modal-content bg-dark vog" data-width="60%" data-height="60%">
                            <iframe allowfullscreen="allowfullscreen" no-src="https://www.youtube.com/embed/6p45ooZOOPo?autoplay=1"></iframe>
                        </div><!--end of modal-content-->
                    </div><!--end of modal-container-->
                </div><!--end of modal instance-->
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->