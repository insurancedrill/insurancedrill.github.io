<!--META--><section class="vim" id="variant-cover-countdown-1" vbr="Cover Countdown 1" vbp="covers">
<section class="imageblock switchable feature-large height-100">
    <div class="imageblock__content col-md-6 col-sm-4 pos-right">
        <div class="background-image-holder">
            <img alt="image" src="<?php variant_page_builder_demo_img('inner-3.jpg'); ?>">
        </div>
    </div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-md-5 col-sm-7">
                <div class="wysiwyg"><h1>Launching Soon</h1></div>
                <span class="h2 countdown color--primary variant-not-editable-mrv" data-date="05/25/2017" data-fallback-text="Getting ready" data-days-text="days"></span>
                <div class="wysiwyg"><p class="lead">We're preparing to launch soon — hit the form below and we'll let you know when we're live.</p></div>
                <div class="cf7-holder">
                	<div class="variant-shortcode vru" data-shortcode-name="contact-form-7" data-param-title="" data-param-id="none">
                		<p class="lead">Manage this form using the section sidebar <i class="material-icons">&#xE5C8;</i></p>
                	</div>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->