<!--META--><section class="vim" id="variant-form-with-text-2" vbr="Form with Text 2" vbp="contact">
<section class="switchable ">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-5">
                <img alt="Image" class="border--round box-shadow-wide" src="<?php variant_page_builder_demo_img('inner-2.jpg'); ?>">
            </div>
            <div class="col-sm-6">
                <div class="row switchable__text">
                	<div class="wysiwyg">
	                    <p class="lead">
	                    E: <a href="#">hello@stack.net</a><br>
	                    P: +613 4827 2294
	                    </p>
	                    <p class="lead">
	                        Give us a call or drop by anytime, we endeavour to answer all enquiries within 24 hours on business days.
	                    </p>
	                    <p class="lead">
	                        We are open from 9am — 5pm week days.
	                    </p>
	                    <hr class="short">
                    </div>
                    <div class="row">
                        <div class="cf7-holder">
                        	<div class="variant-shortcode vru" data-shortcode-name="contact-form-7" data-param-title="" data-param-id="none">
                        		<p class="lead">Manage this form using the section sidebar <i class="material-icons">&#xE5C8;</i></p>
                        	</div>
                        </div>
                    </div><!--end of row-->
                </div><!--end of row-->
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->