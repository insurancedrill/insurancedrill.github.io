<!--META--><section class="vim" id="variant-features-large-10" vbr="Features Large 10" vbp="features large">
<section class="feature-large switchable ">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-6">
                <img alt="Image" class="border--round box-shadow-wide" src="<?php variant_page_builder_demo_img('inner-5.jpg'); ?>">
            </div>
            <div class="col-md-5 col-sm-6">
                <div class="heading-block wysiwyg">
                    <h2>Experience quality design and thoughfully crafted code.</h2>
                </div>
                <div class="text-block voh wysiwyg">
                    <h5>Premium Design</h5>
                    <p>
                        Combine blocks from a range of categories to build pages that are rich in visual style and interactivity.
                    </p>
                </div>
                <div class="text-block voh wysiwyg">
                    <h5>Quality Code</h5>
                    <p>
                        Stack is built with customization and ease-of-use at its core — consistent markup and useful data attribute modifiers make rapid development simple.
                    </p>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->