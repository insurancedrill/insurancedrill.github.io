<!--META--><section class="vim" id="variant-cta-horizontal-1-bg" vbr="CTA Horizontal 1 BG" vbp="CTA">
<section class="space--xs imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
    <div class="container">
        <div class="row">
            <div class="cta cta--horizontal text-center-xs">
                <div class="col-sm-4">
                    <h4>Let's get you started</h4>  
                </div>
                <div class="col-sm-5">
                    <p class="lead">
                        Start building beautiful pages in your browser
                    </p>
                </div>
                <div class="col-sm-3 text-right text-center-xs">
                    <a class="btn btn--primary type--uppercase" href="#">
                        <span class="btn__text">
                            Try Builder
                        </span>
                    </a>
                </div>
            </div>  
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->